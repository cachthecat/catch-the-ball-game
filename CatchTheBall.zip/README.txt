ISTRUZIONI PER INSTALLARE IL GIOCO

1. Sul tuo telefono Android:
   - Crea una cartella chiamata "CatchTheBall"
   - Copia tutti i file di questa cartella ZIP nella cartella "CatchTheBall"

2. Installa "Web Server for Android" dal Play Store
   - Cerca "Web Server for Android" nel Play Store
   - Installa l'app (è gratuita)

3. Avvia il server web:
   - Apri "Web Server for Android"
   - In "Root Directory" seleziona la cartella "CatchTheBall"
   - Premi il pulsante "Start" per avviare il server
   - Vedrai un indirizzo IP (esempio: http://192.168.1.100:8080)

4. Gioca:
   - Apri Chrome sul telefono
   - Vai all'indirizzo mostrato nel server
   - Tocca i tre puntini (⋮) in alto a destra
   - Seleziona "Installa app" o "Aggiungi a schermata Home"

Il gioco sarà installato e apparirà nella tua schermata Home!
